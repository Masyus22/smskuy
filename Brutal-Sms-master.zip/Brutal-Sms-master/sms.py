import os

os.system("clear")
print("[!] Tools dinonaktifkan sementara oleh admin")
print("[!] Silahkan kunjungi yt admin FREE TUTORIAL")
print("[!] Untuk mendapatkan update-an terbaru pastinya..")
os.system("exit")
