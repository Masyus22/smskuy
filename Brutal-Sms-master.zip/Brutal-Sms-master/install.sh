pkg install jq
pkg install curl
python sms.py
